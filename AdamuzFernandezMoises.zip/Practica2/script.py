#!/bin/python3

#Allow execute orders ti a shell in parallel
import subprocess

#Domain
domain = input()
#Orders to execute
data = subprocess.run('ping -c 1 '+domain, shell=True, text=True, capture_output=True)

out = data.stdout
#split with spaces. We use split to get the IP's number making it a array and getting its position 
parserIP = out.split(" ")
ip = parserIP[2].replace("(","").replace(")","")

print(ip)